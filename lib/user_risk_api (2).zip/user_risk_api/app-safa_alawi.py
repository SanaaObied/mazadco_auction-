from flask import Flask, request, jsonify
import joblib
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
import threading
import logging
import mysql.connector

app = Flask(__name__)

model_path = 'model/risk_model.pkl'

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

model = joblib.load(model_path)
logger.info("Model loaded successfully.")

lock = threading.Lock()

db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'database': 'final'
}

def insert_data_to_db(data, risk_level):
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()
        # sql = ("INSERT INTO user_risk_data "
        sql = ("INSERT INTO dataset "

               "(account_authenticity, bidding_score, transaction_score, delivery_score, fraud_reports, risk_level) "
               "VALUES (%s, %s, %s, %s, %s, %s)")
        vals = (
            data.get('account_authenticity', 0),
            data.get('bidding_score', 0),
            data.get('transaction_score', 0),
            data.get('delivery_score', 0),
            data.get('fraud_reports', 0),
            risk_level
        )
        cursor.execute(sql, vals)
        conn.commit()
        cursor.close()
        conn.close()
    except Exception as e:
        logger.error(f"Error inserting data to DB: {e}")


@app.route('/predict-risk', methods=['GET', 'POST'])
def predict_risk():
    logger.info("Received prediction request.")
    try:
        data = request.get_json()
        features = pd.DataFrame([{
            'account_authenticity': data.get('account_authenticity', 0),
            'bidding_score': data.get('bidding_score', 0),
            'transaction_score': data.get('transaction_score', 0),
            'delivery_score': data.get('delivery_score', 0),
            'fraud_reports': data.get('fraud_reports', 0)
        }])

        prediction = model.predict(features)[0]
        risk_map = {0: 'Low', 1: 'Medium', 2: 'High'}
        result = risk_map.get(prediction, 'Unknown')

        logger.info(f"Received data: {data}")
        logger.info(f"Prediction result: {result}")

        with lock:
            insert_data_to_db(data, result)

        return jsonify({'risk_level': result})

    except Exception as e:
        logger.error(f"Error in prediction: {str(e)}")
        return jsonify({'error': 'Failed to process prediction'}), 500


@app.route('/retrain', methods=['POST'])
def retrain():
    global model
    try:
        with lock:
            # Connect and load data from DB
            conn = mysql.connector.connect(**db_config)
            query = "SELECT account_authenticity, bidding_score, transaction_score, delivery_score, fraud_reports, risk_level FROM user_risk_data"
            df = pd.read_sql(query, conn)
            conn.close()

            required_columns = ['account_authenticity', 'bidding_score', 'transaction_score',
                                'delivery_score', 'fraud_reports', 'risk_level']
            if not all(col in df.columns for col in required_columns):
                return jsonify({'error': 'Missing required columns in the dataset'}), 400

            X = df[['account_authenticity', 'bidding_score', 'transaction_score', 'delivery_score',
                    'fraud_reports']]
            y = df['risk_level'].map({'Low': 0, 'Medium': 1, 'High': 2})

            model = DecisionTreeClassifier()
            model.fit(X, y)
            joblib.dump(model, model_path)

        return jsonify({'message': '✅ Model retrained successfully.'})

    except Exception as e:
        logger.error(f"Error during retraining: {str(e)}")
        return jsonify({'error': f"Failed to retrain the model: {str(e)}"}), 500


if __name__ == '__main__':
    app.run(debug=True, use_reloader=False)
