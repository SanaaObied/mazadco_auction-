import pandas as pd

# تحميل الملف
df = pd.read_csv('./balanced_user_behavior.csv')

# حذف العمود (استبدل 'اسم_العمود' بالاسم الفعلي للعمود الذي تريد حذفه)
df = df.drop('delivery_score', axis=1)

# حفظ الملف بعد التعديل (اختياريًا يمكنك الكتابة فوق الملف الأصلي أو إنشاء ملف جديد)
df.to_csv('./balanced_user_behavior_new.csv', index=False)
