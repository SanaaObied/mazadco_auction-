from flask import Flask, request, jsonify
import joblib
import numpy as np
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
import threading

app = Flask(__name__)

model_path = 'model/risk_model.pkl'

model = joblib.load(model_path)
lock = threading.Lock()

@app.route('/predict-risk', methods=['POST'])
def predict_risk():
    global model

    data = request.get_json()

    features = np.array([[  
        data.get('account_authenticity', 0),
        data.get('bidding_score', 0),
        data.get('transaction_score', 0),
        data.get('delivery_score', 0),
        data.get('fraud_reports', 0)
    ]])

    prediction = model.predict(features)[0]

    risk_map = {0: 'Low', 1: 'Medium', 2: 'High'}
    result = risk_map.get(prediction, 'Unknown')

    new_row = pd.DataFrame([{
        'account_authenticity': data.get('account_authenticity', 0),
        'bidding_score': data.get('bidding_score', 0),
        'transaction_score': data.get('transaction_score', 0),
        'delivery_score': data.get('delivery_score', 0),
        'fraud_reports': data.get('fraud_reports', 0),
        'risk_level': result
    }])

    with lock:
        new_row.to_csv('data/user_behavior.csv', mode='a', index=False, header=False)

    return jsonify({'risk_level': result})

@app.route('/retrain', methods=['POST'])
def retrain():
    global model
    try:
        with lock:
            df = pd.read_csv('data/user_behavior.csv')

            X = df[['account_authenticity', 'bidding_score', 'transaction_score', 'delivery_score', 'fraud_reports']]
            y = df['risk_level'].map({'Low': 0, 'Medium': 1, 'High': 2})

            model = DecisionTreeClassifier()
            model.fit(X, y)

            joblib.dump(model, model_path)

        return jsonify({'message': '✅ Model retrained successfully.'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
